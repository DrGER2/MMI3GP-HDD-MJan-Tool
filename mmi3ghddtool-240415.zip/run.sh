#!/bin/ksh

# 20240415 drger; MMI3GP HDD Tool v1

### HDD TOOL CONFIGURATION ###
ACTI_HDDPARTITION=N

### Script startup ###
xversion="v240415"
showScreen ${SDLIB}/mmiscript-h-0.png
touch ${SDPATH}/.started
xlogfile=${SDPATH}/mmi3ghddtool-$(getTime).log
exec > ${xlogfile} 2>&1
umask 022
echo "[INFO] Start: $(date); Timestamp: $(getTime)"

### 20240415 drger; MMI3G HDD Tool ###
echo "[INFO] MMI3G HDD Tool: mmi3ghddtool-$xversion"
echo "[INFO] Credit MJan (2024) for QNX binary hdd-formatter-mjan"

### Get Train and MainUnit software version ###
case "$MUVER" in
MMI3GB | MMI3GH)
  SWTRAIN="$(sloginfo -m 10000 -s 5 |
    sed -n 's/^.* +++ Train //p' | sed -n 1p)" ;;
esac # MUVER-SWTRAIN
echo; echo "[INFO] MU train name: $SWTRAIN"
MUSWVER="$(sed -n 's/^version = //p' /etc/version/MainUnit-version.txt)"
echo "[INFO] MU software version: $MUSWVER"

### MainUnit Variant ###
case "$MUVER" in
MMI3GB) MUVAR="9304" ;;
MMI3GH) MUVAR="9308" ;;
MMI3GP)
  MUVAR="$(sed -n 's,^<VariantName>,,;s,</VariantName>$,,p' \
         /etc/mmi3g-srv-starter.cfg)" ;;
esac # MUVER-MUVAR
echo "[INFO] MU variant: $MUVAR"

### Get hwSample version ###
MUHWSAMPLE="n/a"
[ -e /etc/hwSample ] && MUHWSAMPLE="$(cat /etc/hwSample)"
echo "[INFO] MU hwSample: $MUHWSAMPLE"

### Get installed HDD info from syslog and fdisk ###
HDDINFO="$(sloginfo -m 19 -s 2 | grep 'eide_display_devices.*tid 1' |
  sed 's/^.*mdl //;s/ tid 1.*$//')"
echo
if [ -z "$HDDINFO" ]
then
  echo "[INFO] No HDD reported by eide_display_devices."
else
  if [ -e /dev/hd0 ]
  then
    echo "[INFO] Installed HDD: $HDDINFO"
    HDDC="$(fdisk /dev/hd0 query -T)"
    echo "[INFO] HDD reported cylinders: $HDDC"
    HDDH="$(fdisk /dev/hd0 info | sed -n 's,^    Heads            : ,,p')"
    HDDS="$(fdisk /dev/hd0 info | sed -n 's,^    Sectors/Track    : ,,p')"
    echo "[INFO] HDD capacity (512 byte sectors): $(($HDDC * $HDDH * $HDDS))"
    echo "[INFO] HDD partition table:"
    fdisk /dev/hd0 show
  else
    echo "[INFO] Cannot find device /dev/hd0."
  fi
fi # HDDINFO

## 
if [ -e /dev/hd0 ]
then
  if [ "$ACTI_HDDPARTITION" = Y ]
  then
    echo "[ACTI] Forcing repartition/reformat of /dev/hd0 !"
    hdd-formatter-mjan -d /dev/hd0 -write-force
    sleep 5
    echo "Manual system reboot required !"
  else
    echo "[INFO] Report of /dev/hd0 ..."
    hdd-formatter-mjan -d /dev/hd0
  fi # ACTI_HDDPARTITION
else
  echo "[INFO] Cannot find device /dev/hd0."
fi

### Script cleanup ###
echo; echo "[INFO] End: $(date); Timestamp: $(getTime)"
showScreen ${SDLIB}/mmiscript-h-1.png
rm -f ${SDPATH}/.started
exit 0
